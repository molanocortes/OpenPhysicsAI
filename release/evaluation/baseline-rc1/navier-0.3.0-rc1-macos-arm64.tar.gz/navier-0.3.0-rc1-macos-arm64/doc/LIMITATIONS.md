# Known limitations

## Physics

- **Static, small-strain, linear elasticity with isotropic materials.** Nothing is modelled of plasticity, creep,
  contact, friction, bolt preload, geometric nonlinearity or buckling, dynamic loads, fatigue, temperature effects or
  residual stresses.
- **No strength or safety assessment.** Stress values are supporting information. Peaks at ideal supports and sharp
  inside corners are singular (they grow with refinement) and are labelled so. No failure criterion is applied.
- **Large deformation** is detected, not modelled. A result whose displacement exceeds 5 % of the model size, or
  whose rotation linearisation error exceeds 1e-2, is outside the assumption, and the comparison is not established.
  Between 1 % and 5 % (or 1e-3 and 1e-2) the result is labelled questionable. The thresholds are stated heuristics:
  the rotation criterion follows from the neglected θ²/2 term; the displacement ratio is a common engineering rule of
  thumb, not derived.
- **Supports** are ideal: fixed (all components) or frictionless on flat faces normal to x, y or z.

## Discretisation

- **Voxel hexahedral meshes.** The boundary is a staircase, so inclined and curved faces are approximated, and their
  volume error changes with the element size (reported per level). Features thinner than about two elements are
  poorly resolved, and a mesh that loses a connection, or whose volume differs by more than 10 %, is marked invalid.
  There is no conforming mesher.
- **Uncertainty estimates.**
  - With three meshes in the asymptotic range (monotone, observed order 0.5–4): a grid convergence index with
    safety factor 1.25.
  - Otherwise: three times the last change.
  - A single valid mesh gives no estimate.
  - These are estimates of the discretisation error of the model, not of the model's error against reality.
- **Resources.** The direct solver is used up to 250,000 equations; the iterative solver beyond. On an 8 GB machine,
  about 400,000 elements per analysis is the practical limit (`limits.max_elements`).

## Workflow

- **Two to four designs per study, one material per design, one load case, one payload region.** No load
  combinations, no multiple mounting regions per design beyond the declared alternatives, and no remote point loads
  or moments.
- **Region queries** are geometric (planes, boxes, facing directions, patches). Picks on rendered views cannot define
  a study region, because they are not reproducible.
- **Equivalence between designs** is checked on lever arm, areas and normals of the regions, within stated
  tolerances. It cannot detect every way two designs might be held differently.
- **The ambiguity check** flags regions that span parallel planes. It does not understand intent.
- **Keyword detection** of strength or safety requests is a heuristic that only adds a notice. It never changes the
  computation.
- **Replays** are bitwise reproducible on the same build and machine. Other compilers, CPUs or thread counts may
  change the last digits: the replay record compares with a relative tolerance of 1e-9 and reports bitwise identity
  separately.

## Evaluation status

- **Scripted MCP client:** the reference and evaluation cases in `REFERENCE_CASES.md` run automatically.
- **Real AI client:** not verified. On the build machine, Claude Code's command-line authentication had expired
  (`claude -p`: "OAuth session expired and could not be refreshed"), and Codex was not installed. A harness for
  graded sessions exists in the source tree (`release/evaluation/ai-client/`).
- **External users:** none. No usability or user-testing claim is made.
- **Independent solver:** the CalculiX cross-check is **pending**, because CalculiX is not installed on the build
  machine. The export tool and its instructions are included. The analytical beam benchmark was run.
- **Validation against measurements:** none.

## Platform

The build was made and tested only on macOS arm64 (M2, 8 GB, macOS 15.7.3). See `INSTALL.md`.
