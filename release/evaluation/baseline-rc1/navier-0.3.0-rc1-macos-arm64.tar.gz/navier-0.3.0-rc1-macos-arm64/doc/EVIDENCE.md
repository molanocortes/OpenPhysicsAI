# Numerical evidence

This document says what the comparison workflow checks, how it estimates numerical uncertainty, and what the
reference cases showed. Verification (the equations are solved correctly) is kept apart from validation (the equations
describe reality): **only verification was done**. No result has been compared with a measurement.

## Checks on every analysis

| Check | Criterion | Why it is exact or bounded |
|---|---|---|
| force balance of applied loads, body forces and reactions | ≤ 1e-6 of the force scale | a converged discrete linear-elastic solution balances forces to round-off |
| moment balance about the mounting centroid | ≤ 1e-6 of the moment scale | rigid rotations lie in the null space of the stiffness matrix, so moments balance to round-off |
| Clapeyron: 2U / W | within 1e-6 of 1 | exact for linear statics |
| linear solver | converged; true residual recomputed | a small residual is **not** a discretisation-error estimate |
| rigid-body modes | none before solving | an unsupported motion is refused, never stabilised with springs |
| load application | force preserved to 1e-6; line of action within max(h/2, 1 % of the lever arm) of the load as specified on the geometry | the staircase mesh may move a surface load |
| work-conjugate displacement = region-mean displacement | ≤ 1e-9 relative | a uniform traction does work with the area mean of the displacement |
| mounting region on the mesh | faces present, area ratio in (0.5, 2) | a lost support is not a valid model |
| mesh topology and volume | one connected region; volume within 10 % | a mesh that lost a wall does not represent the design |
| small deformation | displacement ≤ 1 % of model size and rotation error θ²/2 ≤ 1e-3 (questionable up to 5 % / 1e-2) | beyond this a linear result does not describe the loaded part |

## Quantities

- **Load-region displacement:** the area-weighted mean over the region's mesh faces of u · d, with d the unit load
  direction. The displacement is bilinear on each voxel face, so each face contributes the mean of its corners
  exactly. This is the primary quantity by default. It is never the largest nodal displacement.
- **Stiffness:** k = |F|² / W = |F| / (work-conjugate displacement).
- **Mass:** density × the closed STL volume (the design), with the mesh volume beside it.
- **Reactions:** force and moment per support, about the mounting centroid.
- **Stress (supporting information only):**
  - raw Gauss-point and nodal-average maxima, and the nodal 99th percentile;
  - flags for peaks at supports and at sharp inside corners, which are singular;
  - no strength margin.

## Refinement and numerical uncertainty

For each design and quantity over the valid meshes (element sizes descending):

- **Three meshes with a constant ratio and monotone change, observed order p in [0.5, 4]:**
  - Richardson extrapolation;
  - uncertainty U = 1.25 |f₃ − f₂| / (rᵖ − 1), the grid convergence index with safety factor 1.25 (Roache).
- **Monotone with p outside [0.5, 4], or only two meshes:** U = 3 |f₃ − f₂|. Not asymptotic; no extrapolation.
- **Oscillating:** U = the range of the three values.
- **One valid mesh:** no estimate, and the comparison is not resolved.

**Convergence** means that the last relative change is at most `convergence_criterion` (2 % by default).

**Comparison:**

- **resolved** when |Q₁ − Q₂| > U₁ + U₂ for the two best designs, at the finest mesh every design completed validly;
- **too_small_to_distinguish** when both converged but the difference is within U₁ + U₂;
- **not_resolved** or **more_refinement_required** otherwise;
- **cannot_establish** when no level is valid for every design, or the deformation is outside the assumption.

## Reference cases (tested on 2026-09-16, macOS 15.7.3, Apple M2)

Criteria were written before the first run: `REFERENCE_CRITERIA.md`.

### R1: cantilevers against Timoshenko beam theory, through the comparison workflow

Steel test values (E 200 GPa, ν 0.3); root face fixed; 10 N over the tip face; 2.5, 1.25 and 0.625 mm elements.

| Design | Beam theory (mm) | 2.5 / 1.25 / 0.625 mm (mm) | Finest vs theory | Observed order | Extrapolated |
|---|---|---|---|---|---|
| C10 (100 × 10 × 10) | 0.0201560 | 0.0199622 / 0.0199973 / 0.0200115 | −0.717 % | 1.30 | 0.0200211 (−0.67 %) |
| C20 (100 × 10 × 5) | 0.1603120 | 0.1588127 / 0.1590618 / 0.1591834 | −0.704 % | 1.04 | 0.1592991 (−0.63 %) |

- **Stiffness ratio:** C10/C20 = 7.95461 against 7.95356 (+0.013 %).
- **Mass:** exact to 1e-9.
- **Identities:** conjugate displacement = region mean, and balance and energy, all to round-off.
- **E scaling:** verified to 1e-6.
- **Result:** all 29 checks passed.
- **Reading:** the extrapolated values stay about 0.65 % stiffer than beam theory. That is the model difference (a
  fully clamped 3D root restrains warping and Poisson contraction), not discretisation error.

### R2: replay of the bracket example

The replay resolved to the same study hash. 24 of 24 quantities (4 per level, 3 levels, 2 designs) were bitwise
identical: outcome `reproduced`.

### R3: bracket example (no analytical reference)

- Every level of both designs passed its checks. Outcome `resolved`: B's load-region displacement is 0.0087746 mm
  against A's 0.025399 mm, 65.5 % lower.
- Numerical uncertainty: ±0.00025 mm for A (1.0 %, observed order 1.04) and ±0.00032 mm for B (3.7 %, observed order
  1.14).
- B's last mesh change (3.4 %) exceeds the 2 % criterion. The chamfer's staircase volume error falls from −3.6 % to
  −1.8 % to −0.9 % with refinement.

## Independent numerical implementation: **pending**

`share/navier/tools/ccx_crosscheck.py export RUN_DIR OUT_DIR` writes a CalculiX deck of a stored run:

- the same mesh as C3D8I (incompatible modes) or C3D8;
- the same supports (`*BOUNDARY`) and the same consistent nodal loads (`*CLOAD`);
- node sets for every region;
- NAVIER's values for comparison.

`compare` reads CalculiX's displacements and reports region means and the largest nodal difference.

CalculiX was not installed on the build machine, so **no external comparison has been run**, and none is claimed. A
second run of NAVIER is not a substitute. When the comparison is run, the expected sources of difference are:

- the element formulation (CalculiX's C3D8I and NAVIER's Wilson–Taylor incompatible modes differ in detail);
- the solver tolerance.

The geometry, loads and supports are identical by construction.

## Evaluation set

Ten cases with behaviour defined before running are listed in `EVALUATION_CASES.md`: valid comparison, missing
units, missing material, ambiguous mounting, under-constrained part, thin feature, large deformation, printed part
without process data, inconclusive difference, and a stress plot presented as proof of safety. The scripted MCP
client passes all of them (`REFERENCE_CASES.md`). That shows the tools behave as specified. It does not show how an
AI model or a person uses them.
