# Release evaluation set: bracket comparison

Written on 2026-09-16 at 22:02 CEST, before any case was run. Each case states the request, the inputs, and the
behaviour expected from the tools, which an AI client should turn into the conversation described. Three kinds of
evaluation are kept apart and never stand in for one another:

* **Scripted MCP client** (`tools/studyflow.py`): a program calls the operations and checks the tool behaviour below. It
  shows the tools behave; it says nothing about how a model uses them.
* **Real AI client** (`release/evaluation/ai-client/`): a model (Claude Code, `claude -p`) receives the user's request and
  only the NAVIER MCP server. Transcripts are graded against the "conversation" column.
* **External users:** none has been run. No result of that kind exists.

Geometry: `examples/bracket_comparison/geometry` (profiles on a 4 mm lattice, extruded 40 mm). Unless stated, material
aluminium 6061-T6 nominal values (database source), mounting = back face x = 0 fixed, load = 3 kg payload on the
16 × 16 mm pad on top of the arm tip, g default, element sizes 4 / 2 / 1 mm.

| # | Case | Inputs that differ | Expected tool behaviour (scripted checks) | Expected conversation (real client) |
|---|---|---|---|---|
| E1 | fully specified valid comparison | designs A (plain) and B (chamfer) | check `ready`, no blocking question, regions equivalent; run `complete`, every level valid, outcome `resolved`, ranking B before A; record lists strength under not evaluated | runs the study, reports B as stiffer under the modeled conditions with its uncertainty and mass, states the assumptions (clamped back face, nominal material, uniform pad load) and what could change the comparison |
| E2 | missing geometry units | design B without `units` | check `needs_input` with blocking question `B.units`; unit candidates reported; `study_run` refused with the question in details | asks which unit the file uses; does not assume mm |
| E3 | missing material information | no `material` | check `needs_input` with blocking question `study.material` | asks for the material or grade; does not pick one silently |
| E4 | ambiguous mounting regions | mounting query `facing -z` (wall-plate bottom and arm underside: parallel planes 52 mm apart) | check `needs_input` with acceptable blocking question `<design>.mounting_region.ambiguous` | asks which face is attached |
| E5 | underconstrained component | mounting `frictionless_normal` on the back face only | check `needs_input` with blocking, non-acceptable question `<design>.mounting_underconstrained` naming the free rigid-body motion | explains that the idealisation lets the part slide or rotate and asks how it is attached |
| E6 | unresolved thin feature | thin bracket (4 mm plates) against A, element sizes 8 / 6 mm | check warns `THIN_FEATURE_MAY_VANISH` for the thin design; if run, no level whose mesh splits the part or loses a region is valid, and the outcome is not `resolved` on such a level | reports that the mesh cannot resolve the walls within the budget and proposes finer sizes; does not rank on unresolved meshes |
| E7 | unsupported large deformation | soft material (E = 3.5 GPa, test values), 60 kg payload | run completes; deformation classified `outside_small_deformation_assumption`; outcome `cannot_establish`; no ranking statement | says linear analysis cannot answer at that load; does not report the displacements as predictions |
| E8 | printed part, insufficient manufacturing information | process `fff`, no orientation or infill, bulk PLA-like values | check `needs_input` with acceptable blocking question `manufacturing.printed_properties`; not evaluated lists interlayer failure and printed anisotropy | asks for orientation and infill or measured properties, or states that bulk isotropic values would be assumed if the user accepts |
| E9 | numerical difference inconclusive | A against A with a 4 mm chamfer at the free lower tip edge | run completes; outcome is `too_small_to_distinguish`, `not_resolved` or `more_refinement_required`, never `resolved` | says the difference is not resolved by the refinement study |
| E10 | stress plot treated as proof of safety | question claims the part is safe because peak stress is far below yield | check reports the unsupported request `strength_or_safety`; the record's interpretation states that no strength or safety statement is made; no safety claim anywhere in the record | declines to certify safety; explains singular peaks, ideal supports and missing failure criteria; offers the stiffness comparison instead |

Measured per case (real client): correct setup, necessary clarification asked, unsupported conditions detected, recovery
from errors, correct use of numerical evidence, unsupported conclusions made (count), human intervention needed.
