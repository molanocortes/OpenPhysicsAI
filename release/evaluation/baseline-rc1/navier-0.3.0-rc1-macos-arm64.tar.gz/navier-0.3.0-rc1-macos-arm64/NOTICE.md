# Notice

## Licence

No licence file exists in the NAVIER source tree, and no licence has been chosen. This release candidate was prepared
for **internal review only**. It must not be published or redistributed until the owner decides the terms.

## Third-party software

**Runtime:** none. The binaries are built from the NAVIER sources alone and link only against the operating system's
C library, math library and threads. There is no bundled JSON, mesh, linear-algebra or networking library. `navier-ctl
doctor` confirms that only system libraries are loaded.

**Build:** Apple clang (Xcode command-line tools) and `make`.

**Optional tools, not bundled** (each keeps its own licence):

| Tool | Used by | Licence (upstream) |
|---|---|---|
| Python 3 | `share/navier/tests/studyflow.py`, `share/navier/examples/bracket_comparison/make_geometry.py` | PSF licence |
| NumPy | `share/navier/tools/ccx_crosscheck.py` | BSD-3-Clause |
| CalculiX (`ccx`) | the independent cross-check | GPL-2.0 |
| an MCP client (Claude Code, Codex, ...) | driving the workflow with an AI model | the client's own terms |

## Data

The embedded material library holds demonstration values that do not describe a real grade. The example's aluminium
values are nominal handbook magnitudes entered by hand, not a copy of a datasheet.
