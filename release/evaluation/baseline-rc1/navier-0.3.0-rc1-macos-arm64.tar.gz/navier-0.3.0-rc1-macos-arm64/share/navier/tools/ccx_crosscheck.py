#!/usr/bin/env python3
"""ccx_crosscheck.py - an independent numerical check of one NAVIER static run with CalculiX (ccx)

    python3 tools/ccx_crosscheck.py export RUN_DIR OUT_DIR [--elements C3D8I|C3D8]
    python3 tools/ccx_crosscheck.py compare RUN_DIR OUT_DIR

export  reads RUN_DIR/results.nvr (the resolved model NAVIER solved: nodes, hex8 connectivity, prescribed displacement
        components, the consistent nodal loads, materials) and writes OUT_DIR/model.inp for CalculiX: the same mesh as
        C3D8I (incompatible modes, the counterpart of NAVIER's default) or C3D8 (full integration), the same supports as
        *BOUNDARY, the same nodal forces as *CLOAD, linear isotropic *ELASTIC per material, and node sets of every
        selection stored with the run. It also writes OUT_DIR/navier_reference.json with NAVIER's values to compare.
compare reads OUT_DIR/model.dat (CalculiX's *NODE PRINT of U), and reports for every stored selection the mean
        displacement along the load direction (nodal mean, the same definition applied to both solvers' nodal
        displacements) and the largest nodal difference.

What agrees by construction: geometry, mesh, supports, nodal loads and material. What does not, and is the point of
the check: element formulations and implementations (ccx's C3D8I against NAVIER's Wilson-Taylor incompatible modes),
assembly and linear solver. Another solver is not ground truth: a disagreement needs an explanation, not a verdict.
Requires NumPy. ccx itself is not bundled; install CalculiX separately and run `ccx model` in OUT_DIR.
"""
import json
import struct
import sys
from pathlib import Path

import numpy as np

TYPES = {"d": (np.float64, 8), "i": (np.int32, 4), "b": (np.uint8, 1), "c": (np.int8, 1)}


def load_nvr(path):
    with open(path, "rb") as f:
        magic = f.read(8)
        if magic != b"NVRES001":
            raise SystemExit(f"{path}: not a NAVIER results file")
        (hlen,) = struct.unpack("<Q", f.read(8))
        header = json.loads(f.read(hlen))
        arrays = {}
        for a in header["arrays"]:
            dt, size = TYPES[a["type"]]
            n = int(a["count"])
            arrays[a["name"]] = np.frombuffer(f.read(n * size), dtype=dt, count=n) if n else np.zeros(0, dtype=dt)
    return header, arrays


def export(run_dir, out_dir, element="C3D8I"):
    header, A = load_nvr(Path(run_dir) / "results.nvr")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    nn, ne = header["nnodes"], header["nelems"]
    xyz = A["xyz"].reshape(nn, 3) * 1e3            # mm
    conn = A["conn"].reshape(ne, 8) + 1            # 1-based, NAVIER hex8 order = CalculiX C3D8 order
    fixed = A["fixed"].reshape(nn, 3)
    fval = A["fixed_value"].reshape(nn, 3) * 1e3   # mm
    force = A["nodal_force"].reshape(nn, 3)        # N
    mats = header["materials"]
    emat = A["elem_mat"]
    lines = ["** NAVIER run exported for an independent CalculiX check (units: mm, N, MPa)", "*HEADING", f"NAVIER job {header.get('job_id', '')}", "*NODE, NSET=NALL"]
    lines += [f"{i + 1}, {x[0]:.12g}, {x[1]:.12g}, {x[2]:.12g}" for i, x in enumerate(xyz)]
    for m, mat in enumerate(mats):
        ids = np.nonzero(emat == m)[0]
        if not len(ids):
            continue
        lines.append(f"*ELEMENT, TYPE={element}, ELSET=MAT{m}")
        lines += [f"{e + 1}, " + ", ".join(str(int(v)) for v in conn[e]) for e in ids]
        lines += [f"*MATERIAL, NAME=M{m}", "*ELASTIC", f"{mat['E'] * 1e-6:.12g}, {mat['nu']:.12g}", f"*SOLID SECTION, ELSET=MAT{m}, MATERIAL=M{m}"]
    for s, st in enumerate(header.get("sets", [])):
        nodes = A.get(f"set{s}_nodes")
        if nodes is None or not len(nodes):
            continue
        lines.append(f"*NSET, NSET={st['name'].upper()}")
        ids = [str(int(v) + 1) for v in nodes]
        lines += [", ".join(ids[k:k + 16]) for k in range(0, len(ids), 16)]
    lines += ["*STEP", "*STATIC", "*BOUNDARY"]
    for i in range(nn):
        for k in range(3):
            if fixed[i, k]:
                lines.append(f"{i + 1}, {k + 1}, {k + 1}, {fval[i, k]:.12g}")
    if any(abs(g) > 0 for g in header.get("gravity", [0, 0, 0])):
        lines.append("** NOTE: this run had gravity; body forces are not exported. Compare runs without self-weight.")
    lines.append("*CLOAD")
    for i in range(nn):
        for k in range(3):
            if force[i, k] != 0:
                lines.append(f"{i + 1}, {k + 1}, {force[i, k]:.15g}")
    lines += ["*NODE PRINT, NSET=NALL", "U", "*END STEP", ""]
    (out / "model.inp").write_text("\n".join(lines))
    u = A["u"].reshape(nn, 3) * 1e3
    ref = {"job_id": header.get("job_id"), "element_formulation_navier": header["settings"]["formulation"], "element_ccx": element,
           "nodes": nn, "elements": ne, "sets": {}}
    load = next((b for b in header.get("bcs", []) if b["kind"] in ("force", "traction")), None)
    direction = np.array(load["requested"]) / np.linalg.norm(load["requested"]) if load else np.array([0, 0, -1.0])
    ref["direction"] = direction.tolist()
    for s, st in enumerate(header.get("sets", [])):
        nodes = A.get(f"set{s}_nodes")
        if nodes is not None and len(nodes):
            ref["sets"][st["name"]] = {"nodal_mean_along_direction_mm": float(np.mean(u[nodes] @ direction)), "nodes": int(len(nodes))}
    (out / "navier_reference.json").write_text(json.dumps(ref, indent=1))
    print(f"wrote {out / 'model.inp'} ({nn} nodes, {ne} {element} elements) and navier_reference.json")
    print(f"next: cd '{out}' && ccx model && python3 {Path(__file__).name} compare '{run_dir}' '{out}'")


def read_dat_displacements(path, nn):
    u = np.full((nn, 3), np.nan)
    reading = False
    for line in Path(path).read_text().splitlines():
        if "displacements (vx,vy,vz)" in line:
            reading = True
            continue
        if reading:
            parts = line.split()
            if len(parts) == 4:
                try:
                    i = int(parts[0]) - 1
                    u[i] = [float(p) for p in parts[1:]]
                    continue
                except ValueError:
                    pass
            if parts and u[~np.isnan(u[:, 0])].shape[0] > 0:
                reading = False
    return u


def compare(run_dir, out_dir):
    header, A = load_nvr(Path(run_dir) / "results.nvr")
    out = Path(out_dir)
    ref = json.loads((out / "navier_reference.json").read_text())
    nn = header["nnodes"]
    dat = out / "model.dat"
    if not dat.exists():
        raise SystemExit(f"{dat} not found: run CalculiX first (ccx model)")
    uc = read_dat_displacements(dat, nn)
    un = A["u"].reshape(nn, 3) * 1e3
    d = np.array(ref["direction"])
    report = {"sets": {}, "max_nodal_difference_mm": float(np.nanmax(np.linalg.norm(uc - un, axis=1))),
              "max_nodal_displacement_navier_mm": float(np.max(np.linalg.norm(un, axis=1)))}
    for s, st in enumerate(header.get("sets", [])):
        nodes = A.get(f"set{s}_nodes")
        if nodes is None or not len(nodes):
            continue
        a, b = float(np.mean(un[nodes] @ d)), float(np.nanmean(uc[nodes] @ d))
        report["sets"][st["name"]] = {"navier_mm": a, "ccx_mm": b, "relative_difference": (b - a) / a if a else None}
    (out / "comparison.json").write_text(json.dumps(report, indent=1))
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    if len(sys.argv) < 4 or sys.argv[1] not in ("export", "compare"):
        print(__doc__)
        sys.exit(2)
    if sys.argv[1] == "export":
        element = sys.argv[sys.argv.index("--elements") + 1] if "--elements" in sys.argv else "C3D8I"
        export(sys.argv[2], sys.argv[3], element)
    else:
        compare(sys.argv[2], sys.argv[3])
